DROP DATABASE IF EXISTS fancy_pantry_db;

CREATE DATABASE fancy_pantry_db;
